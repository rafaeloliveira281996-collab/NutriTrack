import React, { createContext, useState, useContext, useEffect, useMemo, useCallback, ReactNode } from 'react';
import { User, Profile, NutritionalGoals, DailyLog, WaterLog, CommunityPost, Recipe, FastingSession, Challenge, UserChallengeProgress, Reminder, AppNotification, MealType, FoodItem, Comment } from '../types';
import { calculateNutritionalNeeds } from '../utils/calculations';
import { getTodayDateString, generateId } from '../utils/helpers';
import { DEFAULT_RECIPES, DEFAULT_CHALLENGES, DEFAULT_POSTS } from '../constants';

type Theme = 'light' | 'dark';
type Screen = 'dashboard' | 'community' | 'recipes' | 'reports';

interface AppContextType {
    user: User | null;
    goals: NutritionalGoals | null;
    dailyLog: DailyLog | null;
    waterLog: WaterLog | null;
    communityPosts: CommunityPost[];
    recipes: Recipe[];
    activeFastingSession: FastingSession | null;
    userChallenges: UserChallengeProgress[];
    reminders: Reminder[];
    notifications: AppNotification[];
    theme: Theme;
    activeScreen: Screen;
    coachMode: boolean;
    login: (email: string) => void;
    logout: () => void;
    updateProfile: (profile: Profile) => void;
    addFood: (meal: MealType, food: Omit<FoodItem, 'id' | 'timestamp'>) => void;
    removeFood: (meal: MealType, foodId: string) => void;
    updateWater: (amount: number) => void;
    toggleTheme: () => void;
    setActiveScreen: (screen: Screen) => void;
    addPost: (post: Omit<CommunityPost, 'id' | 'authorId' | 'authorName' | 'likes' | 'comments' | 'timestamp' | 'savedBy'>) => void;
    toggleLikePost: (postId: string) => void;
    addCommentToPost: (postId: string, commentText: string) => void;
    startFasting: (durationHours: number) => void;
    stopFasting: () => void;
    startChallenge: (challengeId: string) => void;
    completeChallengeDay: (challengeId: string) => void;
    addReminder: (reminder: Omit<Reminder, 'id'>) => void;
    updateReminder: (reminder: Reminder) => void;
    deleteReminder: (reminderId: string) => void;
    markNotificationAsRead: (id: string) => void;
    clearCoachMode: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const getInitialState = <T,>(key: string, defaultValue: T): T => {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
        console.error(`Error reading from localStorage key “${key}”:`, error);
        return defaultValue;
    }
};

interface AppProviderProps {
    children: ReactNode;
}

// Fix: Changed to React.FC to potentially fix type inference issues in consuming files.
export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
    const [user, setUser] = useState<User | null>(() => getInitialState('user', null));
    const [theme, setTheme] = useState<Theme>(() => getInitialState('theme', 'light'));
    const [activeScreen, setActiveScreen] = useState<Screen>('dashboard');
    const [coachMode, setCoachMode] = useState<boolean>(false);
    
    // Derived and memoized state
    const today = getTodayDateString();
    const storageKeyPrefix = useMemo(() => user ? `${user.id}_${today}` : null, [user, today]);

    const [dailyLog, setDailyLog] = useState<DailyLog | null>(null);
    const [waterLog, setWaterLog] = useState<WaterLog | null>(null);

    const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>(() => getInitialState('community_posts', DEFAULT_POSTS));
    const [recipes] = useState<Recipe[]>(DEFAULT_RECIPES);
    const [challenges] = useState<Challenge[]>(DEFAULT_CHALLENGES);
    const [userChallenges, setUserChallenges] = useState<UserChallengeProgress[]>([]);
    const [reminders, setReminders] = useState<Reminder[]>([]);
    const [notifications, setNotifications] = useState<AppNotification[]>([]);
    const [activeFastingSession, setActiveFastingSession] = useState<FastingSession | null>(null);

    const goals = useMemo(() => user ? calculateNutritionalNeeds(user.profile) : null, [user]);

    // Load user-specific data from localStorage on user change
    useEffect(() => {
        if (user && storageKeyPrefix) {
            setDailyLog(getInitialState(`${storageKeyPrefix}_dailyLog`, { breakfast: [], lunch: [], dinner: [], snack: [] }));
            setWaterLog(getInitialState(`${storageKeyPrefix}_waterLog`, { amount: 0 }));
            setUserChallenges(getInitialState(`${user.id}_userChallenges`, []));
            setReminders(getInitialState(`${user.id}_reminders`, []));
            setNotifications(getInitialState(`${user.id}_notifications`, []));
            setActiveFastingSession(getInitialState(`${user.id}_activeFasting`, null));
            
            // Coach mode check
            const lastLogDateStr = getInitialState(`${user.id}_lastLogDate`, null);
            if (lastLogDateStr) {
                const lastLogDate = new Date(lastLogDateStr);
                const diffDays = (new Date().getTime() - lastLogDate.getTime()) / (1000 * 3600 * 24);
                if (diffDays >= 2) {
                    setCoachMode(true);
                }
            }

        } else {
            setDailyLog(null);
            setWaterLog(null);
        }
    }, [user, storageKeyPrefix]);

    // Save data to localStorage whenever it changes
    const useStorageEffect = <T,>(key: string | null, data: T) => {
        useEffect(() => {
            if (key) {
                try {
                    localStorage.setItem(key, JSON.stringify(data));
                } catch (error) {
                    console.error(`Error writing to localStorage key “${key}”:`, error);
                }
            }
        }, [key, data]);
    };

    useStorageEffect('user', user);
    useStorageEffect('theme', theme);
    useStorageEffect('community_posts', communityPosts);
    useStorageEffect(user ? `${user.id}_userChallenges` : null, userChallenges);
    useStorageEffect(user ? `${user.id}_reminders` : null, reminders);
    useStorageEffect(user ? `${user.id}_notifications` : null, notifications);
    useStorageEffect(user ? `${user.id}_activeFasting` : null, activeFastingSession);
    useStorageEffect(storageKeyPrefix ? `${storageKeyPrefix}_dailyLog` : null, dailyLog);
    useStorageEffect(storageKeyPrefix ? `${storageKeyPrefix}_waterLog` : null, waterLog);

    const updateLastLogDate = useCallback(() => {
        if(user) {
            localStorage.setItem(`${user.id}_lastLogDate`, today);
        }
    }, [user, today]);

    const addNotification = useCallback((message: string, type: AppNotification['type']) => {
        if (!user) return;
        setNotifications(prev => {
            const newNotif = { id: generateId(), message, type, timestamp: Date.now(), read: false };
            const updatedNotifs = [newNotif, ...prev];
            // keep last 20 notifications
            return updatedNotifs.slice(0, 20);
        });
    }, [user]);

    // Check for goal completion
    useEffect(() => {
        if (!dailyLog || !goals || !waterLog) return;
    
        // FIX: Explicitly type reduce callback parameters to resolve type inference issues.
        const totalCalories = Object.values(dailyLog).flat().reduce((sum: number, item: FoodItem) => sum + item.calories, 0);
        // FIX: Explicitly type reduce callback parameters to resolve type inference issues.
        const totalCarbs = Object.values(dailyLog).flat().reduce((sum: number, item: FoodItem) => sum + item.carbs, 0);
        
        const notifyOnce = (key: string, message: string) => {
            const notifiedKey = `${storageKeyPrefix}_notified_${key}`;
            if (!localStorage.getItem(notifiedKey)) {
                addNotification(message, 'success');
                localStorage.setItem(notifiedKey, 'true');
            }
        };

        if (totalCalories >= goals.calories) {
            notifyOnce('calories', `Parabéns! Você atingiu sua meta de calorias 🎉`);
        } else if (totalCalories >= goals.calories * 0.9) {
            notifyOnce('calories_almost', `Quase lá! Falta pouco para sua meta de calorias ⚡`);
        }
        
        if (totalCarbs >= goals.carbs) {
            notifyOnce('carbs', `Você atingiu sua meta de carboidratos!`);
        } else if (totalCarbs >= goals.carbs * 0.9) {
            notifyOnce('carbs_almost', `Quase lá! Falta pouco para sua meta de carboidratos ⚡`);
        }
        
        if (waterLog.amount >= goals.water) {
            notifyOnce('water', `Meta de hidratação atingida! Ótimo trabalho! 💧`);
        }

    }, [dailyLog, waterLog, goals, addNotification, storageKeyPrefix]);

    // Simulated timed notifications
    useEffect(() => {
        const checkNotifications = () => {
            const now = new Date();
            const hour = now.getHours();
            const notifiedKey = (key: string) => `${today}_notified_${key}`;

            if(hour >= 8 && hour < 9 && !localStorage.getItem(notifiedKey('drink_water_8am'))) {
                addNotification('Lembrete: Hora de beber água!', 'info');
                localStorage.setItem(notifiedKey('drink_water_8am'), 'true');
            }
            if(hour >= 12 && hour < 13 && !localStorage.getItem(notifiedKey('log_lunch'))) {
                addNotification('Não se esqueça de registrar seu almoço!', 'info');
                localStorage.setItem(notifiedKey('log_lunch'), 'true');
            }
            if(hour >= 21 && hour < 22 && !localStorage.getItem(notifiedKey('daily_summary'))) {
                // FIX: Explicitly type reduce callback parameters to resolve type inference issues.
                const totalCalories = dailyLog ? Object.values(dailyLog).flat().reduce((sum: number, item: FoodItem) => sum + item.calories, 0) : 0;
                addNotification(`Resumo diário: Você consumiu ${totalCalories} de ${goals?.calories || 0} kcal.`, 'info');
                localStorage.setItem(notifiedKey('daily_summary'), 'true');
            }
        };
        const interval = setInterval(checkNotifications, 60 * 1000); // Check every minute
        return () => clearInterval(interval);
    }, [addNotification, dailyLog, goals, today]);


    const login = (email: string) => {
        const userId = 'user_' + email.replace(/[^a-zA-Z0-9]/g, '');
        let storedUser = getInitialState<User | null>(`user_${userId}`, null);
        
        if (storedUser) {
            setUser(storedUser);
        } else {
            const defaultProfile: Profile = {
                name: 'Novo Usuário',
                age: 30,
                sex: 'male',
                weight: 70,
                height: 175,
                unitSystem: 'metric',
                activityLevel: 'moderate',
                practicesSports: false,
                sport: '',
                otherSport: '',
                goal: 'maintain_weight',
                targetWeight: 70,
                goalTimeframe: 'no_deadline',
                healthConditions: ['none'],
                allergies: ['none'],
                otherAllergy: '',
                dietStyle: 'normal',
                likesSweets: false,
                likesSavory: true,
                eatsOutFrequently: false,
                cooksAtHome: true,
                waterConsumption: 'medium',
                alcoholConsumption: 'sometimes',
                sleepDuration: '7_8',
                sleepQuality: 'good',
                disciplineLevel: 'medium',
                motivationPreferences: ['recipes'],
                notificationPreference: 'important_only',
                allowLocalData: true,
                allowAutoPersonalization: true,
            };

            const newUser: User = {
                id: userId,
                email: email,
                profile: defaultProfile
            };
            setUser(newUser);
            localStorage.setItem(`user_${userId}`, JSON.stringify(newUser));
        }
        setActiveScreen('dashboard');
    };

    const logout = () => setUser(null);

    const updateProfile = (profile: Profile) => {
        if (!user) return;
        const updatedUser = { ...user, profile };
        setUser(updatedUser);
        localStorage.setItem(`user_${user.id}`, JSON.stringify(updatedUser));
    };

    const addFood = (meal: MealType, food: Omit<FoodItem, 'id' | 'timestamp'>) => {
        if (!dailyLog) return;
        const newFoodItem: FoodItem = {
            ...food,
            id: generateId(),
            timestamp: Date.now(),
        };
        setDailyLog(prev => ({ ...prev!, [meal]: [...(prev![meal] || []), newFoodItem] }));
        updateLastLogDate();
    };

    const removeFood = (meal: MealType, foodId: string) => {
        if (!dailyLog) return;
        setDailyLog(prev => ({ ...prev!, [meal]: prev![meal].filter(item => item.id !== foodId) }));
    };

    const updateWater = (amount: number) => {
        if (!waterLog) return;
        const newAmount = Math.max(0, waterLog.amount + amount);
        setWaterLog({ amount: newAmount });
        updateLastLogDate();
    };

    const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

    const addPost = (postData: Omit<CommunityPost, 'id' | 'authorId' | 'authorName' | 'likes' | 'comments' | 'timestamp' | 'savedBy'>) => {
        if (!user) return;
        const newPost: CommunityPost = {
            ...postData,
            id: generateId(),
            authorId: user.id,
            authorName: user.profile.name,
            likes: [],
            comments: [],
            timestamp: Date.now(),
            savedBy: []
        };
        setCommunityPosts(prev => [newPost, ...prev]);
    };

    const toggleLikePost = (postId: string) => {
        if (!user) return;
        setCommunityPosts(posts => posts.map(p => {
            if (p.id === postId) {
                const liked = p.likes.includes(user.id);
                const newLikes = liked ? p.likes.filter(id => id !== user.id) : [...p.likes, user.id];
                return { ...p, likes: newLikes };
            }
            return p;
        }));
    };

    const addCommentToPost = (postId: string, commentText: string) => {
        if (!user) return;
        const newComment: Comment = {
            id: generateId(),
            authorId: user.id,
            authorName: user.profile.name,
            text: commentText,
            timestamp: Date.now(),
        };
        setCommunityPosts(posts => posts.map(p => p.id === postId ? { ...p, comments: [...p.comments, newComment] } : p));
    };

    const startFasting = (durationHours: number) => {
        const now = Date.now();
        const session: FastingSession = {
            id: generateId(),
            startTime: now,
            endTime: now + durationHours * 3600 * 1000,
            durationHours,
            completed: false,
            completionNotified: false
        };
        setActiveFastingSession(session);
    };

    const stopFasting = () => setActiveFastingSession(null);

    const startChallenge = (challengeId: string) => {
        if (userChallenges.some(c => c.challengeId === challengeId && !c.isCompleted)) return;
        const newChallenge: UserChallengeProgress = {
            challengeId,
            startDate: Date.now(),
            completedDays: [],
            isCompleted: false
        };
        setUserChallenges(prev => [...prev.filter(c => c.challengeId !== challengeId), newChallenge]);
    };

    const completeChallengeDay = (challengeId: string) => {
        setUserChallenges(prev => prev.map(c => {
            if (c.challengeId === challengeId) {
                const dayNumber = Math.floor((Date.now() - c.startDate) / (24 * 3600 * 1000)) + 1;
                if (c.completedDays.includes(dayNumber)) return c;
                
                const newCompletedDays = [...c.completedDays, dayNumber];
                const challengeDef = challenges.find(ch => ch.id === challengeId);
                const isCompleted = challengeDef ? newCompletedDays.length >= challengeDef.durationDays : false;

                if (isCompleted) {
                    addNotification(`Desafio "${challengeDef?.name}" concluído!`, 'success');
                }

                return { ...c, completedDays: newCompletedDays, isCompleted };
            }
            return c;
        }));
    };

    const addReminder = (reminder: Omit<Reminder, 'id'>) => {
        setReminders(prev => [...prev, { ...reminder, id: generateId() }]);
    };
    
    const updateReminder = (updatedReminder: Reminder) => {
        setReminders(prev => prev.map(r => r.id === updatedReminder.id ? updatedReminder : r));
    };
    
    const deleteReminder = (reminderId: string) => {
        setReminders(prev => prev.filter(r => r.id !== reminderId));
    };

    const markNotificationAsRead = (id: string) => {
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    };

    const clearCoachMode = () => setCoachMode(false);

    return (
        <AppContext.Provider value={{
            user, goals, dailyLog, waterLog, communityPosts, recipes, activeFastingSession,
            userChallenges, reminders, notifications, theme, activeScreen, coachMode,
            login, logout, updateProfile, addFood, removeFood, updateWater, toggleTheme,
            setActiveScreen, addPost, toggleLikePost, addCommentToPost, startFasting,
            stopFasting, startChallenge, completeChallengeDay, addReminder, updateReminder,
            deleteReminder, markNotificationAsRead, clearCoachMode
        }}>
            {children}
        </AppContext.Provider>
    );
};

export const useApp = () => {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useApp must be used within an AppProvider');
    }
    return context;
};