
import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';

const LoginScreen: React.FC = () => {
  const { login } = useApp();
  const [email, setEmail] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      login(email);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-light-background dark:bg-dark-background p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-accent">NutriTrack</h1>
            <p className="text-light-subtext dark:text-dark-subtext mt-2">Your minimalist health companion.</p>
        </div>
        <form onSubmit={handleLogin} className="bg-light-card dark:bg-dark-card p-8 rounded-xl shadow-md space-y-6">
          <h2 className="text-xl font-semibold text-center text-light-text dark:text-dark-text">Login or Register</h2>
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            aria-label="Email"
          />
          <Button type="submit" className="w-full" size="lg">
            Continue
          </Button>
        </form>
      </div>
    </div>
  );
};

export default LoginScreen;
