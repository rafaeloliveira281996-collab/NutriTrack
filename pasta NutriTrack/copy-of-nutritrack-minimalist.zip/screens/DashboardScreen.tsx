import React, { useState, useMemo } from 'react';
import { useApp } from '../contexts/AppContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
// FIX: Import FoodItem to use for type annotation.
import { MealType, FoodItem } from '../types';
import { PlusIcon } from '../components/icons/PlusIcon';
import { MinusIcon } from '../components/icons/MinusIcon';
import { TrashIcon } from '../components/icons/TrashIcon';
import AddFoodModal from '../modals/AddFoodModal';
import FastingModal from '../modals/FastingModal';
import ChallengesModal from '../modals/ChallengesModal';
import { FlameIcon } from '../components/icons/FlameIcon';
import { ZapIcon } from '../components/icons/ZapIcon';

const MacroProgress: React.FC<{ label: string; consumed: number; goal: number; unit: string }> = ({ label, consumed, goal, unit }) => {
    const percentage = goal > 0 ? (consumed / goal) * 100 : 0;
    return (
        <div className="flex flex-col items-center">
            <div className="relative h-20 w-20">
                <svg className="h-full w-full" viewBox="0 0 36 36">
                    <path className="text-light-border dark:text-dark-border" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" strokeWidth="3"></path>
                    <path className="text-accent" strokeDasharray={`${percentage}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" strokeWidth="3" strokeLinecap="round"></path>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="font-bold text-sm">{Math.round(consumed)}</span>
                    <span className="text-xs text-light-subtext dark:text-dark-subtext">/ {Math.round(goal)}{unit}</span>
                </div>
            </div>
            <span className="text-sm font-medium mt-2">{label}</span>
        </div>
    );
};

const CoachModeCard: React.FC = () => {
    const { coachMode, clearCoachMode } = useApp();
    if (!coachMode) return null;
    return (
        <Card className="bg-accent text-white mb-6">
            <h3 className="font-bold text-lg">Let's get back on track!</h3>
            <p className="mt-1 mb-3">We've missed you. Logging your meals is the first step towards your goal. You can do it!</p>
            <Button variant="secondary" size="sm" onClick={clearCoachMode}>Entendi</Button>
        </Card>
    );
}

const DashboardScreen: React.FC = () => {
    const { goals, dailyLog, waterLog, updateWater, removeFood, activeFastingSession, coachMode, clearCoachMode } = useApp();
    const [isAddFoodModalOpen, setAddFoodModalOpen] = useState(false);
    const [isFastingModalOpen, setFastingModalOpen] = useState(false);
    const [isChallengesModalOpen, setChallengesModalOpen] = useState(false);
    const [selectedMeal, setSelectedMeal] = useState<MealType>('breakfast');

    const totals = useMemo(() => {
        if (!dailyLog) return { calories: 0, protein: 0, carbs: 0, fat: 0 };
        // Fix: Explicitly type the accumulator in reduce to prevent type inference issues.
        return Object.values(dailyLog).flat().reduce(
            (acc: { calories: number; protein: number; carbs: number; fat: number; }, item: FoodItem) => ({
                calories: acc.calories + item.calories,
                protein: acc.protein + item.protein,
                carbs: acc.carbs + item.carbs,
                fat: acc.fat + item.fat,
            }), { calories: 0, protein: 0, carbs: 0, fat: 0 }
        );
    }, [dailyLog]);

    const openAddFoodModal = (meal: MealType) => {
        setSelectedMeal(meal);
        setAddFoodModalOpen(true);
    };

    const meals: { type: MealType; name: string }[] = [
        { type: 'breakfast', name: 'Café da Manhã' },
        { type: 'lunch', name: 'Almoço' },
        { type: 'dinner', name: 'Jantar' },
        { type: 'snack', name: 'Lanche' },
    ];
    
    return (
        <div className="space-y-6">
            <CoachModeCard />

            {/* Quick Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Button onClick={() => setFastingModalOpen(true)} variant="secondary" size="lg">Jejum Intermitente</Button>
                <Button onClick={() => setChallengesModalOpen(true)} variant="secondary" size="lg">Desafios</Button>
                <Button onClick={() => openAddFoodModal('snack')} size="lg">Adicionar Alimento</Button>
            </div>

            {/* Calories Summary */}
            <Card>
                <div className="flex justify-between items-center">
                    <h3 className="font-bold text-lg">Resumo de Calorias</h3>
                    <FlameIcon className="h-6 w-6 text-accent" />
                </div>
                <div className="text-center my-4">
                    <p className="text-5xl font-bold">{Math.round(totals.calories)}</p>
                    <p className="text-light-subtext dark:text-dark-subtext">de {goals?.calories} kcal</p>
                </div>
                <div className="w-full bg-light-border dark:bg-dark-border rounded-full h-2.5">
                    <div className="bg-accent h-2.5 rounded-full" style={{ width: `${goals ? (totals.calories / goals.calories) * 100 : 0}%` }}></div>
                </div>
                <div className="grid grid-cols-3 gap-4 text-center mt-4">
                    <div><p className="font-bold">{Math.round(goals?.carbs || 0)}g</p><p className="text-xs">Carbs</p></div>
                    <div><p className="font-bold">{Math.round(goals?.protein || 0)}g</p><p className="text-xs">Proteína</p></div>
                    <div><p className="font-bold">{Math.round(goals?.fat || 0)}g</p><p className="text-xs">Gordura</p></div>
                </div>
            </Card>

            {/* Macros & Water */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                    <h3 className="font-bold text-lg mb-4">Macronutrientes</h3>
                    <div className="flex justify-around">
                        <MacroProgress label="Proteína" consumed={totals.protein} goal={goals?.protein || 0} unit="g"/>
                        <MacroProgress label="Carbs" consumed={totals.carbs} goal={goals?.carbs || 0} unit="g"/>
                        <MacroProgress label="Gordura" consumed={totals.fat} goal={goals?.fat || 0} unit="g"/>
                    </div>
                </Card>
                <Card>
                    <h3 className="font-bold text-lg mb-4">Hidratação</h3>
                     <div className="flex items-center justify-center space-x-4">
                         <Button onClick={() => updateWater(-250)} variant="secondary" size="sm" className="p-2 h-10 w-10 !rounded-full"><MinusIcon className="h-5 w-5"/></Button>
                         <div className="text-center">
                            <p className="text-3xl font-bold">{waterLog?.amount || 0} ml</p>
                            <p className="text-light-subtext dark:text-dark-subtext">de {goals?.water} ml</p>
                         </div>
                         <Button onClick={() => updateWater(250)} variant="secondary" size="sm" className="p-2 h-10 w-10 !rounded-full"><PlusIcon className="h-5 w-5"/></Button>
                     </div>
                </Card>
            </div>
            
            {/* Meal Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {meals.map(({ type, name }) => (
                    <Card key={type}>
                        <div className="flex justify-between items-center mb-3">
                            <h4 className="font-bold">{name}</h4>
                            <Button onClick={() => openAddFoodModal(type)} variant="ghost" size="sm" className="!p-2 rounded-full">
                                <PlusIcon className="h-5 w-5" />
                            </Button>
                        </div>
                        <div className="space-y-2">
                            {dailyLog && dailyLog[type].length > 0 ? (
                                dailyLog[type].map(item => (
                                    <div key={item.id} className="flex justify-between items-center text-sm p-2 rounded-lg bg-light-background dark:bg-dark-background">
                                        <div>
                                            <p className="font-semibold">{item.name}</p>
                                            <p className="text-xs text-light-subtext dark:text-dark-subtext">{item.calories} kcal &bull; {item.portion}</p>
                                        </div>
                                        <button onClick={() => removeFood(type, item.id)} className="text-red-500 hover:text-red-700 p-1">
                                            <TrashIcon className="h-4 w-4" />
                                        </button>
                                    </div>
                                ))
                            ) : (
                                <p className="text-sm text-light-subtext dark:text-dark-subtext text-center py-4">Nenhum alimento registrado</p>
                            )}
                        </div>
                    </Card>
                ))}
            </div>

            <AddFoodModal isOpen={isAddFoodModalOpen} onClose={() => setAddFoodModalOpen(false)} mealType={selectedMeal} />
            <FastingModal isOpen={isFastingModalOpen} onClose={() => setFastingModalOpen(false)} />
            <ChallengesModal isOpen={isChallengesModalOpen} onClose={() => setChallengesModalOpen(false)} />
        </div>
    );
};

export default DashboardScreen;