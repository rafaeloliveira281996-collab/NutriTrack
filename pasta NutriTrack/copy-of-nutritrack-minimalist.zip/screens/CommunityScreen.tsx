import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { HeartIcon } from '../components/icons/HeartIcon';
import { ChatAltIcon } from '../components/icons/ChatAltIcon';
import { BookmarkIcon } from '../components/icons/BookmarkIcon';
import { CommunityPost } from '../types';

const PostCard: React.FC<{ post: CommunityPost }> = ({ post }) => {
    const { user, toggleLikePost, addCommentToPost } = useApp();
    const [commentText, setCommentText] = useState('');
    const [showComments, setShowComments] = useState(false);

    const isLiked = user ? post.likes.includes(user.id) : false;

    const handleCommentSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (commentText.trim()) {
            addCommentToPost(post.id, commentText);
            setCommentText('');
        }
    };
    
    return (
        <Card className="mb-4">
            <div className="flex items-center mb-3">
                <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center text-white font-bold mr-3">{post.authorName.charAt(0)}</div>
                <div>
                    <p className="font-bold">{post.authorName}</p>
                    <p className="text-xs text-light-subtext dark:text-dark-subtext">{new Date(post.timestamp).toLocaleDateString()}</p>
                </div>
            </div>
            <p className="mb-3">{post.text}</p>
            {post.imageUrl && <img src={post.imageUrl} alt="Post content" className="rounded-lg mb-3 w-full" />}
            <div className="flex items-center justify-between text-light-subtext dark:text-dark-subtext border-t border-b border-light-border dark:border-dark-border py-2">
                <Button variant="ghost" onClick={() => toggleLikePost(post.id)} className={`flex items-center space-x-1 ${isLiked ? 'text-red-500' : ''}`}>
                    <HeartIcon className="h-5 w-5" /> <span>{post.likes.length} Curtir</span>
                </Button>
                <Button variant="ghost" onClick={() => setShowComments(!showComments)} className="flex items-center space-x-1">
                    <ChatAltIcon className="h-5 w-5" /> <span>{post.comments.length} Comentar</span>
                </Button>
                <Button variant="ghost" className="flex items-center space-x-1">
                    <BookmarkIcon className="h-5 w-5" /> <span>Salvar</span>
                </Button>
            </div>
            {showComments && (
                <div className="mt-4 space-y-3">
                    {post.comments.map(comment => (
                        <div key={comment.id} className="flex items-start text-sm">
                            <div className="w-8 h-8 rounded-full bg-light-border dark:bg-dark-border flex items-center justify-center text-xs font-bold mr-2 shrink-0">{comment.authorName.charAt(0)}</div>
                            <div className="flex-1 bg-light-background dark:bg-dark-background p-2 rounded-lg border border-light-border dark:border-dark-border">
                                <p><span className="font-bold">{comment.authorName}</span> {comment.text}</p>
                            </div>
                        </div>
                    ))}
                    <form onSubmit={handleCommentSubmit} className="flex space-x-2">
                        <Input 
                            value={commentText} 
                            onChange={(e) => setCommentText(e.target.value)} 
                            placeholder="Adicionar um comentário..."
                            className="flex-1"
                        />
                        <Button type="submit" size="sm">Postar</Button>
                    </form>
                </div>
            )}
        </Card>
    );
};

const CommunityScreen: React.FC = () => {
    const { communityPosts, addPost } = useApp();
    const [newPostText, setNewPostText] = useState('');
    const [category, setCategory] = useState<'Tips' | 'From the Kitchen' | 'Motivation' | 'Progress'>('Motivation');
    const [filter, setFilter] = useState<'all' | CommunityPost['category']>('all');

    const handlePostSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newPostText.trim()) {
            addPost({ text: newPostText, category });
            setNewPostText('');
        }
    };
    
    const categories: CommunityPost['category'][] = ['Tips', 'From the Kitchen', 'Motivation', 'Progress'];

    const filteredPosts = filter === 'all' ? communityPosts : communityPosts.filter(p => p.category === filter);

    return (
        <div className="max-w-2xl mx-auto">
            <Card className="mb-6">
                <form onSubmit={handlePostSubmit}>
                    <textarea
                        value={newPostText}
                        onChange={(e) => setNewPostText(e.target.value)}
                        placeholder="Compartilhe algo..."
                        className="w-full p-2 bg-light-background dark:bg-dark-background border border-light-border dark:border-dark-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent"
                        rows={3}
                    ></textarea>
                    <div className="flex justify-between items-center mt-2">
                        <select value={category} onChange={e => setCategory(e.target.value as any)} className="bg-light-background dark:bg-dark-background border border-light-border dark:border-dark-border rounded-lg px-2 py-1 text-sm">
                           {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                        </select>
                        <Button type="submit">Postar</Button>
                    </div>
                </form>
            </Card>

            <div className="flex flex-wrap gap-2 mb-4">
                <Button variant={filter === 'all' ? 'primary' : 'secondary'} size="sm" onClick={() => setFilter('all')}>Todos</Button>
                {categories.map(cat => (
                    <Button key={cat} variant={filter === cat ? 'primary' : 'secondary'} size="sm" onClick={() => setFilter(cat)}>{cat}</Button>
                ))}
            </div>

            <div>
                {filteredPosts.map(post => <PostCard key={post.id} post={post} />)}
            </div>
        </div>
    );
};

export default CommunityScreen;