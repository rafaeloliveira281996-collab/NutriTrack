
import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Card } from '../components/ui/Card';
import { Recipe } from '../types';
import RecipeModal from '../modals/RecipeModal';

const RecipesScreen: React.FC = () => {
    const { recipes } = useApp();
    const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

    return (
        <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recipes.map(recipe => (
                    <Card key={recipe.id} onClick={() => setSelectedRecipe(recipe)} className="cursor-pointer hover:shadow-lg transition-shadow">
                        <img src={`https://picsum.photos/seed/${recipe.id}/400/200`} alt={recipe.name} className="rounded-lg mb-4 w-full h-40 object-cover" />
                        <h3 className="font-bold text-lg">{recipe.name}</h3>
                        <div className="flex justify-between text-sm text-light-subtext dark:text-dark-subtext mt-2">
                            <span>{recipe.totalMacros.calories} kcal</span>
                            <span>{recipe.ingredients.length} ingredients</span>
                        </div>
                    </Card>
                ))}
            </div>

            {selectedRecipe && (
                <RecipeModal
                    isOpen={!!selectedRecipe}
                    onClose={() => setSelectedRecipe(null)}
                    recipe={selectedRecipe}
                />
            )}
        </>
    );
};

export default RecipesScreen;
