import React from 'react';
import { useApp } from '../contexts/AppContext';
import { Card } from '../components/ui/Card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
// FIX: Import FoodItem to use for type annotation.
import { FoodItem } from '../types';

const ReportsScreen: React.FC = () => {
    const { goals, dailyLog, waterLog } = useApp();
    
    // This is mock data for demonstration. In a real app, you'd pull historical data.
    const weeklyData = [
        { name: 'Seg', calories: 1800, water: 2000 },
        { name: 'Ter', calories: 1950, water: 2200 },
        { name: 'Qua', calories: 1700, water: 1800 },
        { name: 'Qui', calories: 2100, water: 2500 },
        { name: 'Sex', calories: 2200, water: 2300 },
        { name: 'Sáb', calories: 2400, water: 2100 },
        { name: 'Dom', calories: 2050, water: 2600 },
    ];
    
    const totals = React.useMemo(() => {
        if (!dailyLog) return { calories: 0, protein: 0, carbs: 0, fat: 0 };
        // Fix: Explicitly type the accumulator in reduce to prevent type inference issues.
        return Object.values(dailyLog).flat().reduce(
            (acc: { calories: number; protein: number; carbs: number; fat: number; }, item: FoodItem) => ({
                calories: acc.calories + item.calories,
                protein: acc.protein + item.protein,
                carbs: acc.carbs + item.carbs,
                fat: acc.fat + item.fat,
            }), { calories: 0, protein: 0, carbs: 0, fat: 0 }
        );
    }, [dailyLog]);
    
    const macroData = [
        { name: 'Proteína', value: totals.protein, goal: goals?.protein },
        { name: 'Carbs', value: totals.carbs, goal: goals?.carbs },
        { name: 'Gordura', value: totals.fat, goal: goals?.fat },
    ];

    return (
        <div className="space-y-6">
            <Card>
                <h3 className="font-bold text-lg mb-4">Consumo Semanal (Calorias)</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={weeklyData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip contentStyle={{ backgroundColor: 'var(--color-card)', border: '1px solid var(--color-border)'}}/>
                        <Legend />
                        <Line type="monotone" dataKey="calories" stroke="#14C57C" strokeWidth={2} activeDot={{ r: 8 }} />
                    </LineChart>
                </ResponsiveContainer>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <h3 className="font-bold text-lg mb-4">Hidratação Semanal</h3>
                     <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={weeklyData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip contentStyle={{ backgroundColor: 'var(--color-card)', border: '1px solid var(--color-border)'}}/>
                            <Legend />
                            <Bar dataKey="water" fill="#3A7AFE" />
                        </BarChart>
                    </ResponsiveContainer>
                </Card>
                <Card>
                    <h3 className="font-bold text-lg mb-4">Macronutrientes Hoje (g)</h3>
                     <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={macroData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip contentStyle={{ backgroundColor: 'var(--color-card)', border: '1px solid var(--color-border)'}}/>
                            <Legend />
                            <Bar dataKey="value" name="Consumido" fill="#14C57C" />
                            <Bar dataKey="goal" name="Meta" fill="#a0a0a0" />
                        </BarChart>
                    </ResponsiveContainer>
                </Card>
            </div>
        </div>
    );
};

export default ReportsScreen;