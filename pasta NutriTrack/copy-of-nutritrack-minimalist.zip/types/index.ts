export interface User {
  id: string;
  email: string;
  profile: Profile;
}

export type Sex = 'male' | 'female' | 'prefer_not_to_say';
export type UnitSystem = 'metric' | 'imperial';
export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active' | 'very_active';
export type Sport = '' | 'walking' | 'running' | 'gym' | 'yoga' | 'functional' | 'team_sports' | 'other';
export type UserGoal = 'lose_weight' | 'gain_muscle' | 'tone_body' | 'improve_fitness' | 'maintain_weight' | 'reduce_measurements' | 'healthier_lifestyle';
export type GoalTimeframe = '30_days' | '60_days' | '90_days' | 'no_deadline';
export type DietStyle = 'normal' | 'vegetarian' | 'vegan' | 'low_carb' | 'high_protein' | 'free';
export type WaterConsumption = 'low' | 'medium' | 'high';
export type AlcoholConsumption = 'never' | 'sometimes' | 'frequently';
export type SleepDuration = 'less_5' | '5_6' | '6_7' | '7_8' | 'more_8';
export type SleepQuality = 'bad' | 'average' | 'good';
export type DisciplineLevel = 'low' | 'medium' | 'high';
export type MotivationType = 'quotes' | 'videos' | 'workout_suggestions' | 'recipes';
export type NotificationPreference = 'yes' | 'no' | 'important_only';


export interface Profile {
  // Section 1: User Profile
  name: string;
  age: number;
  sex: Sex;
  weight: number;
  height: number;
  unitSystem: UnitSystem;

  // Routine & Physical Activity
  activityLevel: ActivityLevel;
  practicesSports: boolean;
  sport?: Sport;
  otherSport?: string;

  // Section 2: User Goals
  goal: UserGoal;
  targetWeight?: number;
  goalTimeframe: GoalTimeframe;

  // Section 3: Health Status
  healthConditions: string[]; // e.g. ['hypertension']
  allergies: string[]; // e.g. ['lactose', 'gluten']
  otherAllergy?: string;

  // Section 4: Eating Routine
  dietStyle: DietStyle;
  likesSweets: boolean;
  likesSavory: boolean;
  eatsOutFrequently: boolean;
  cooksAtHome: boolean;
  waterConsumption: WaterConsumption;
  alcoholConsumption: AlcoholConsumption;

  // Section 5: Sleep Habits
  sleepDuration: SleepDuration;
  sleepQuality: SleepQuality;

  // Section 6: Behavioral Data
  disciplineLevel: DisciplineLevel;
  motivationPreferences: string[]; // e.g. ['quotes', 'recipes']
  notificationPreference: NotificationPreference;

  // Section 7: Privacy
  allowLocalData: boolean;
  allowAutoPersonalization: boolean;
}


export interface NutritionalGoals {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  water: number; // in ml
}

export interface FoodItem {
  id: string;
  name:string;
  portion: string; // e.g., "100g" or "1 cup"
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  timestamp: number;
}

export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export type DailyLog = {
  [key in MealType]: FoodItem[];
};

export interface WaterLog {
  amount: number; // in ml
}

export interface CommunityPost {
  id: string;
  authorId: string;
  authorName: string;
  text: string;
  imageUrl?: string;
  likes: string[]; // array of user IDs
  comments: Comment[];
  category: 'Tips' | 'From the Kitchen' | 'Motivation' | 'Progress';
  timestamp: number;
  savedBy: string[]; // array of user IDs
}

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  text: string;
  timestamp: number;
}

export interface Recipe {
  id: string;
  name: string;
  ingredients: { name: string; amount: string; item: Omit<FoodItem, 'id' | 'timestamp' | 'portion'>}[];
  instructions: string[];
  totalMacros: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  }
}

export interface FastingSession {
  id: string;
  startTime: number;
  endTime: number;
  durationHours: number;
  completed: boolean;
  completionNotified: boolean;
}

export interface Challenge {
  id: string;
  name: string;
  description: string;
  durationDays: number; // e.g., 7 for a weekly challenge
}

export interface UserChallengeProgress {
  challengeId: string;
  startDate: number;
  completedDays: number[]; // e.g. [1, 2, 4] for days completed
  isCompleted: boolean;
}

export interface Reminder {
  id: string;
  name: string;
  time: string; // "HH:MM"
  active: boolean;
}

export interface AppNotification {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning';
  timestamp: number;
  read: boolean;
}