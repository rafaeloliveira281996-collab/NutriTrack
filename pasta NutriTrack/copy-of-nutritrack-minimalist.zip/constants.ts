
import { Recipe, Challenge, CommunityPost } from './types';
import { generateId } from './utils/helpers';

export const DEFAULT_RECIPES: Recipe[] = [
  {
    id: 'rec1',
    name: 'Oatmeal with Berries',
    instructions: [
      'Combine oats and water/milk in a pot.',
      'Bring to a boil, then simmer for 5 minutes.',
      'Top with fresh berries and a drizzle of honey.'
    ],
    totalMacros: { calories: 350, protein: 10, carbs: 65, fat: 5 },
    ingredients: [
      { name: 'Rolled Oats', amount: '1/2 cup', item: { name: 'Oats', calories: 150, protein: 5, carbs: 27, fat: 3 } },
      { name: 'Mixed Berries', amount: '1 cup', item: { name: 'Berries', calories: 85, protein: 1, carbs: 21, fat: 0.5 } },
      { name: 'Almond Milk', amount: '1 cup', item: { name: 'Almond Milk', calories: 60, protein: 1, carbs: 8, fat: 2.5 } },
      { name: 'Honey', amount: '1 tbsp', item: { name: 'Honey', calories: 64, protein: 0, carbs: 17, fat: 0 } }
    ]
  },
   {
    id: 'rec2',
    name: 'Grilled Chicken Salad',
    instructions: [
      'Grill chicken breast until cooked through.',
      'Chop mixed greens, cherry tomatoes, and cucumber.',
      'Slice the chicken and place it on top of the salad.',
      'Drizzle with olive oil and lemon juice.'
    ],
    totalMacros: { calories: 450, protein: 40, carbs: 15, fat: 25 },
    ingredients: [
      { name: 'Chicken Breast', amount: '150g', item: { name: 'Chicken Breast', calories: 248, protein: 45, carbs: 0, fat: 5 } },
      { name: 'Mixed Greens', amount: '2 cups', item: { name: 'Mixed Greens', calories: 20, protein: 2, carbs: 4, fat: 0 } },
      { name: 'Cherry Tomatoes', amount: '1/2 cup', item: { name: 'Cherry Tomatoes', calories: 15, protein: 1, carbs: 3, fat: 0 } },
      { name: 'Olive Oil', amount: '1 tbsp', item: { name: 'Olive Oil', calories: 119, protein: 0, carbs: 0, fat: 14 } },
      { name: 'Lemon Juice', amount: '1 tbsp', item: { name: 'Lemon Juice', calories: 3, protein: 0, carbs: 1, fat: 0 } }
    ]
  }
];

export const DEFAULT_CHALLENGES: Challenge[] = [
  { id: 'ch1', name: 'Hydration Hero', description: 'Drink 2.5 liters of water every day for a week.', durationDays: 7 },
  { id: 'ch2', name: 'Protein Power', description: 'Meet your protein goal every day for 5 days.', durationDays: 5 },
  { id: 'ch3', name: 'Mindful Mover', description: 'Log at least 30 minutes of activity for 7 straight days.', durationDays: 7 }
];

export const DEFAULT_POSTS: CommunityPost[] = [
    {
        id: 'post1',
        authorId: 'system',
        authorName: 'Alex',
        text: 'Just tried the Grilled Chicken Salad recipe from the app! So delicious and easy. #DirectFromTheKitchen',
        category: 'From the Kitchen',
        likes: [],
        comments: [
            { id: generateId(), authorId: 'system2', authorName: 'Maria', text: 'Looks amazing!', timestamp: Date.now() }
        ],
        timestamp: Date.now() - 86400000,
        savedBy: []
    },
    {
        id: 'post2',
        authorId: 'system2',
        authorName: 'Maria',
        text: 'Feeling so energetic after a week of hitting my hydration goals. Stick with it, everyone! 💪 #Motivation',
        category: 'Motivation',
        likes: [],
        comments: [],
        timestamp: Date.now() - 172800000,
        savedBy: []
    }
];
