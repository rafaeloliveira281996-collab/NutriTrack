
import React from 'react';

export const UsersIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m-7.5-2.962a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM12 15.75a9 9 0 10-9 9m4.501-4.501a5.97 5.97 0 015.176 2.45m5.176-2.45a5.97 5.97 0 00-5.176-2.45m0 0A2.25 2.25 0 0115 13.5m-3 0a2.25 2.25 0 00-3 0m0 0a2.25 2.25 0 01-3 0m0 0a2.25 2.25 0 00-3 0m7.5 0a7.47 7.47 0 016.75 0" />
  </svg>
);
