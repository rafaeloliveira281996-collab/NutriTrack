
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  className?: string;
}

export const Input: React.FC<InputProps> = ({ label, className = '', ...props }) => {
  return (
    <div className="w-full">
      {label && <label className="block text-sm font-medium text-light-subtext dark:text-dark-subtext mb-1">{label}</label>}
      <input
        className={`w-full px-3 py-2 bg-light-background dark:bg-dark-background border border-light-border dark:border-dark-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent dark:focus:border-accent text-light-text dark:text-dark-text ${className}`}
        {...props}
      />
    </div>
  );
};
