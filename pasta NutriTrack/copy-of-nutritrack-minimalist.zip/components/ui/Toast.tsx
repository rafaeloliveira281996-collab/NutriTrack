
import React, { useState, useEffect } from 'react';

interface ToastProps {
  message: string;
  type: 'success' | 'info' | 'warning';
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
    const timer = setTimeout(() => {
      setVisible(false);
      setTimeout(onClose, 300); // Wait for fade out
    }, 3000);

    return () => clearTimeout(timer);
  }, [onClose]);

  const baseStyle = "fixed top-20 right-5 p-4 rounded-lg shadow-lg text-white transition-all duration-300 z-50";
  const typeStyles = {
    success: 'bg-accent',
    info: 'bg-blue-500',
    warning: 'bg-yellow-500',
  };
  
  const visibilityClass = visible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform -translate-y-5';

  return (
    <div className={`${baseStyle} ${typeStyles[type]} ${visibilityClass}`}>
      {message}
    </div>
  );
};
