
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const Card: React.FC<CardProps> = ({ children, className = '', onClick }) => {
  const cursorStyle = onClick ? 'cursor-pointer' : '';
  return (
    <div
      className={`bg-light-card dark:bg-dark-card rounded-xl shadow-sm border border-light-border dark:border-dark-border p-4 md:p-6 ${cursorStyle} ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  );
};
