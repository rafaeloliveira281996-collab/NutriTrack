
import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { MenuIcon } from '../icons/MenuIcon';
import { BellIcon } from '../icons/BellIcon';
import { UserCircleIcon } from '../icons/UserCircleIcon';
import ProfileModal from '../../modals/ProfileModal';
import NotificationsModal from '../../modals/NotificationsModal';

interface TopBarProps {
  onMenuClick: () => void;
}

const TopBar: React.FC<TopBarProps> = ({ onMenuClick }) => {
  const { activeScreen, user, notifications } = useApp();
  const [isProfileModalOpen, setProfileModalOpen] = useState(false);
  const [isNotificationsModalOpen, setNotificationsModalOpen] = useState(false);

  const screenTitles: { [key: string]: string } = {
    dashboard: 'Dashboard',
    community: 'Community',
    recipes: 'Recipes',
    reports: 'Reports',
  };

  const unreadNotifications = notifications.filter(n => !n.read).length;

  return (
    <>
      <header className="flex-shrink-0 bg-light-card dark:bg-dark-card border-b border-light-border dark:border-dark-border px-4 md:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <button onClick={onMenuClick} className="md:hidden mr-4 p-2 -ml-2">
            <MenuIcon className="h-6 w-6" />
          </button>
          <h2 className="text-xl font-bold capitalize">{screenTitles[activeScreen]}</h2>
        </div>
        <div className="flex items-center space-x-4">
          <button onClick={() => setNotificationsModalOpen(true)} className="relative p-2 rounded-full hover:bg-light-border dark:hover:bg-dark-border">
            <BellIcon className="h-6 w-6" />
            {unreadNotifications > 0 && (
              <span className="absolute top-0 right-0 h-4 w-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {unreadNotifications}
              </span>
            )}
          </button>
          <button onClick={() => setProfileModalOpen(true)} className="flex items-center space-x-2">
            <UserCircleIcon className="h-8 w-8 text-light-subtext dark:text-dark-subtext" />
            <span className="hidden md:block font-semibold">{user?.profile.name}</span>
          </button>
        </div>
      </header>
      <ProfileModal isOpen={isProfileModalOpen} onClose={() => setProfileModalOpen(false)} />
      <NotificationsModal isOpen={isNotificationsModalOpen} onClose={() => setNotificationsModalOpen(false)} />
    </>
  );
};

export default TopBar;
