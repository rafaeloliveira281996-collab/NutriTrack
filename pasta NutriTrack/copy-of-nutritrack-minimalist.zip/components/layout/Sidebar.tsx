import React from 'react';
import { useApp } from '../../contexts/AppContext';
import { Screen } from '../../App';
import { HomeIcon } from '../icons/HomeIcon';
import { UsersIcon } from '../icons/UsersIcon';
import { BookOpenIcon } from '../icons/BookOpenIcon';
import { ChartBarIcon } from '../icons/ChartBarIcon';
import { SunIcon } from '../icons/SunIcon';
import { MoonIcon } from '../icons/MoonIcon';
import { LogoutIcon } from '../icons/LogoutIcon';
import { XIcon } from '../icons/XIcon';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, setIsOpen }) => {
  const { activeScreen, setActiveScreen, theme, toggleTheme, logout, user } = useApp();

  // FIX: Replace JSX.Element with React.ReactElement to fix namespace error.
  const navItems: { screen: Screen; label: string; icon: React.ReactElement }[] = [
    { screen: 'dashboard', label: 'Dashboard', icon: <HomeIcon className="h-6 w-6" /> },
    { screen: 'community', label: 'Community', icon: <UsersIcon className="h-6 w-6" /> },
    { screen: 'recipes', label: 'Recipes', icon: <BookOpenIcon className="h-6 w-6" /> },
    { screen: 'reports', label: 'Reports', icon: <ChartBarIcon className="h-6 w-6" /> },
  ];

  // FIX: Replace JSX.Element with React.ReactElement to fix namespace error.
  const NavLink = ({ screen, label, icon }: { screen: Screen; label: string; icon: React.ReactElement }) => (
    <button
      onClick={() => {
          setActiveScreen(screen);
          setIsOpen(false);
      }}
      className={`flex items-center w-full px-4 py-3 rounded-lg transition-colors duration-200 ${
        activeScreen === screen
          ? 'bg-accent text-white'
          : 'text-light-subtext dark:text-dark-subtext hover:bg-light-border dark:hover:bg-dark-border'
      }`}
    >
      {icon}
      <span className="ml-4 font-semibold">{label}</span>
    </button>
  );

  return (
    <>
        <div 
            className={`fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity md:hidden ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
            onClick={() => setIsOpen(false)}
        />
        <aside className={`fixed top-0 left-0 h-full bg-light-card dark:bg-dark-card border-r border-light-border dark:border-dark-border w-64 p-4 flex flex-col z-40 transform transition-transform md:relative md:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between mb-8">
            <h1 className="text-2xl font-bold text-accent">NutriTrack</h1>
            <button onClick={() => setIsOpen(false)} className="md:hidden p-1">
                <XIcon className="h-6 w-6" />
            </button>
        </div>

        <div className="flex-1">
            <nav className="space-y-2">
            {/* FIX: Use spread operator for props. `key` is handled by React and not passed down. */}
            {navItems.map((item) => (
                <NavLink key={item.screen} {...item} />
            ))}
            </nav>
        </div>

        <div className="space-y-4">
            <div className="flex items-center justify-between p-2 rounded-lg bg-light-background dark:bg-dark-background">
                <span className="text-sm font-medium">{theme === 'light' ? 'Light Mode' : 'Dark Mode'}</span>
                <button onClick={toggleTheme} className="p-2 rounded-full bg-accent text-white">
                    {theme === 'light' ? <MoonIcon className="h-5 w-5"/> : <SunIcon className="h-5 w-5"/>}
                </button>
            </div>
            <button onClick={logout} className="flex items-center w-full px-4 py-3 rounded-lg transition-colors duration-200 text-light-subtext dark:text-dark-subtext hover:bg-red-500 hover:text-white">
                <LogoutIcon className="h-6 w-6" />
                <span className="ml-4 font-semibold">Logout</span>
            </button>
        </div>
        </aside>
    </>
  );
};

export default Sidebar;