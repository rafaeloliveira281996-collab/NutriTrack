
import React, { useEffect } from 'react';
import { useApp } from './contexts/AppContext';
import LoginScreen from './screens/LoginScreen';
import DashboardScreen from './screens/DashboardScreen';
import CommunityScreen from './screens/CommunityScreen';
import RecipesScreen from './screens/RecipesScreen';
import ReportsScreen from './screens/ReportsScreen';
import Layout from './components/layout/Layout';

export type Screen = 'dashboard' | 'community' | 'recipes' | 'reports';

export default function App() {
  const { user, theme, activeScreen } = useApp();

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const renderScreen = () => {
    switch (activeScreen) {
      case 'dashboard':
        return <DashboardScreen />;
      case 'community':
        return <CommunityScreen />;
      case 'recipes':
        return <RecipesScreen />;
      case 'reports':
        return <ReportsScreen />;
      default:
        return <DashboardScreen />;
    }
  };

  if (!user) {
    return <LoginScreen />;
  }

  return <Layout>{renderScreen()}</Layout>;
}
