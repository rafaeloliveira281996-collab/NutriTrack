
import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Modal } from '../components/ui/Modal';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { MealType } from '../types';

interface AddFoodModalProps {
  isOpen: boolean;
  onClose: () => void;
  mealType: MealType;
}

const AddFoodModal: React.FC<AddFoodModalProps> = ({ isOpen, onClose, mealType }) => {
  const { addFood } = useApp();
  const [name, setName] = useState('');
  const [portion, setPortion] = useState('');
  const [calories, setCalories] = useState('');
  const [protein, setProtein] = useState('');
  const [carbs, setCarbs] = useState('');
  const [fat, setFat] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const food = {
      name,
      portion,
      calories: parseInt(calories) || 0,
      protein: parseInt(protein) || 0,
      carbs: parseInt(carbs) || 0,
      fat: parseInt(fat) || 0,
    };
    if (food.name && food.calories > 0) {
      addFood(mealType, food);
      onClose();
      // Reset form
      setName(''); setPortion(''); setCalories(''); setProtein(''); setCarbs(''); setFat('');
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Adicionar Alimento em ${mealType}`}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input label="Nome do Alimento" value={name} onChange={e => setName(e.target.value)} required />
        <Input label="Peso/Porção (ex: 100g)" value={portion} onChange={e => setPortion(e.target.value)} required />
        <div className="grid grid-cols-2 gap-4">
            <Input label="Calorias" type="number" value={calories} onChange={e => setCalories(e.target.value)} required />
            <Input label="Proteína (g)" type="number" value={protein} onChange={e => setProtein(e.target.value)} />
            <Input label="Carboidratos (g)" type="number" value={carbs} onChange={e => setCarbs(e.target.value)} />
            <Input label="Gordura (g)" type="number" value={fat} onChange={e => setFat(e.target.value)} />
        </div>
        <Button type="submit" className="w-full">Adicionar</Button>
      </form>
    </Modal>
  );
};

export default AddFoodModal;
