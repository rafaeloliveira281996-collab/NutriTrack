
import React, { useState, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';
import { Modal } from '../components/ui/Modal';
import { Button } from '../components/ui/Button';
import { formatTime } from '../utils/helpers';

const FastingModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { activeFastingSession, startFasting, stopFasting } = useApp();
  const [duration, setDuration] = useState(16);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (activeFastingSession && isOpen) {
      const interval = setInterval(() => {
        const remaining = Math.max(0, (activeFastingSession.endTime - Date.now()) / 1000);
        setTimeLeft(remaining);
        if (remaining === 0) {
          clearInterval(interval);
        }
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [activeFastingSession, isOpen]);

  const handleStartFasting = () => {
    startFasting(duration);
  };
  
  if (activeFastingSession) {
    return (
      <Modal isOpen={isOpen} onClose={onClose} title="Jejum Ativo">
        <div className="text-center space-y-4">
          <p className="text-5xl font-bold">{formatTime(timeLeft)}</p>
          <p className="text-light-subtext dark:text-dark-subtext">
            Jejum termina em {new Date(activeFastingSession.endTime).toLocaleTimeString()}
          </p>
          <div className="w-full bg-light-border dark:bg-dark-border rounded-full h-2.5">
            <div className="bg-accent h-2.5 rounded-full" style={{ width: `${100 - (timeLeft / (activeFastingSession.durationHours * 36))}%` }}></div>
          </div>
          <Button variant="danger" onClick={() => { stopFasting(); onClose(); }} className="w-full">Cancelar Jejum</Button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Iniciar Jejum Intermitente">
      <div className="space-y-4 text-center">
        <label className="block text-lg font-medium">Duração do jejum (horas):</label>
        <div className="flex items-center justify-center space-x-4">
            <Button onClick={() => setDuration(d => Math.max(1, d - 1))}>-</Button>
            <span className="text-2xl font-bold w-16 text-center">{duration}</span>
            <Button onClick={() => setDuration(d => d + 1)}>+</Button>
        </div>
        <Button onClick={handleStartFasting} className="w-full">Iniciar Jejum</Button>
      </div>
    </Modal>
  );
};

export default FastingModal;
