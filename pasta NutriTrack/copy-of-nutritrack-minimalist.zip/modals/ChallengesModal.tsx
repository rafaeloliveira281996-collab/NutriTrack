
import React from 'react';
import { useApp } from '../contexts/AppContext';
import { Modal } from '../components/ui/Modal';
import { Button } from '../components/ui/Button';
import { DEFAULT_CHALLENGES } from '../constants';

const ChallengesModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { userChallenges, startChallenge, completeChallengeDay } = useApp();

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Desafios e Conquistas">
      <div className="space-y-4">
        {DEFAULT_CHALLENGES.map(challenge => {
          const userProgress = userChallenges.find(uc => uc.challengeId === challenge.id);
          const canCompleteToday = userProgress && !userProgress.isCompleted && !userProgress.completedDays.includes(Math.floor((Date.now() - userProgress.startDate) / (24*3600*1000)) + 1);

          return (
            <div key={challenge.id} className="p-4 rounded-lg bg-light-background dark:bg-dark-background border border-light-border dark:border-dark-border">
              <h4 className="font-bold">{challenge.name}</h4>
              <p className="text-sm text-light-subtext dark:text-dark-subtext mt-1">{challenge.description}</p>
              
              {userProgress ? (
                <div className="mt-3">
                  <div className="w-full bg-light-border dark:bg-dark-border rounded-full h-2.5">
                    <div className="bg-accent h-2.5 rounded-full" style={{ width: `${(userProgress.completedDays.length / challenge.durationDays) * 100}%` }}></div>
                  </div>
                  <p className="text-xs text-center mt-1">{userProgress.completedDays.length} / {challenge.durationDays} dias</p>
                  {userProgress.isCompleted ? (
                     <p className="text-center font-bold text-accent mt-2">Desafio Concluído! 🎉</p>
                  ) : canCompleteToday ? (
                    <Button onClick={() => completeChallengeDay(challenge.id)} size="sm" className="w-full mt-2">Marcar dia como concluído</Button>
                  ) : <p className="text-center text-sm text-light-subtext dark:text-dark-subtext mt-2">Volte amanhã!</p>}
                </div>
              ) : (
                <Button onClick={() => startChallenge(challenge.id)} size="sm" className="w-full mt-3">Iniciar Desafio</Button>
              )}
            </div>
          );
        })}
      </div>
    </Modal>
  );
};

export default ChallengesModal;
