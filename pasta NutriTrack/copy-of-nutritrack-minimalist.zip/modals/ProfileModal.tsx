import React, { useState, useEffect } from 'react';
import { useApp } from '../contexts/AppContext';
import { Modal } from '../components/ui/Modal';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { Profile } from '../types';

const FormSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="mb-6">
    <h3 className="font-bold text-md mb-3 border-b border-light-border dark:border-dark-border pb-2">{title}</h3>
    <div className="space-y-4 text-sm">{children}</div>
  </div>
);

const Checkbox: React.FC<React.InputHTMLAttributes<HTMLInputElement> & { label: string }> = ({ label, ...props }) => (
    <label className="flex items-center space-x-2 cursor-pointer">
        <input type="checkbox" className="rounded text-accent focus:ring-accent-dark border-light-border dark:border-dark-border bg-light-background dark:bg-dark-background" {...props} />
        <span>{label}</span>
    </label>
);

const ProfileModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { user, updateProfile } = useApp();
  const [profile, setProfile] = useState<Profile | null>(user?.profile || null);

  useEffect(() => {
    if (user) {
      setProfile(user.profile);
    }
  }, [user, isOpen]);

  if (!profile) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    let finalValue: string | number | boolean = value;
    if (type === 'number') {
        finalValue = value ? parseFloat(value) : '';
    }
    if (name === 'practicesSports' || name === 'likesSweets' || name === 'likesSavory' || name === 'eatsOutFrequently' || name === 'cooksAtHome' || name === 'allowLocalData' || name === 'allowAutoPersonalization') {
        finalValue = value === 'true';
    }
    setProfile(p => p ? { ...p, [name]: finalValue } : null);
  };

  const handleMultiSelectChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, checked } = e.target;
    setProfile(p => {
        if (!p) return null;
        const currentValues = (p[name as keyof Profile] as string[]) || [];
        let newValues: string[];

        if (checked) {
            newValues = [...currentValues.filter(v => v !== 'none'), value];
        } else {
            newValues = currentValues.filter(v => v !== value);
        }
        
        if (newValues.length === 0) {
            newValues.push('none');
        }

        return { ...p, [name]: newValues };
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (profile) {
      updateProfile(profile);
      onClose();
    }
  };
  
  const Select = ({label, ...props}: React.SelectHTMLAttributes<HTMLSelectElement> & {label: string}) => (
      <div>
        <label className="block text-sm font-medium text-light-subtext dark:text-dark-subtext mb-1">{label}</label>
        <select {...props} className="w-full px-3 py-2 bg-light-background dark:bg-dark-background border border-light-border dark:border-dark-border rounded-lg" />
      </div>
  )

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Meu Perfil e Metas">
      <form onSubmit={handleSubmit} className="space-y-4">
        
        <FormSection title="1. Perfil do Usuário">
            <Input label="Nome" name="name" value={profile.name} onChange={handleChange} />
            <div className="grid grid-cols-2 gap-4">
                <Input label="Idade" name="age" type="number" value={profile.age} onChange={handleChange} />
                <Select label="Sexo" name="sex" value={profile.sex} onChange={handleChange}>
                    <option value="male">Masculino</option>
                    <option value="female">Feminino</option>
                    <option value="prefer_not_to_say">Prefiro não informar</option>
                </Select>
                <Input label="Peso (kg)" name="weight" type="number" value={profile.weight} onChange={handleChange} />
                <Input label="Altura (cm)" name="height" type="number" value={profile.height} onChange={handleChange} />
            </div>
        </FormSection>

        <FormSection title="2. Rotina & Atividade Física">
            <Select label="Nível de atividade diária" name="activityLevel" value={profile.activityLevel} onChange={handleChange}>
                <option value="sedentary">Sedentário</option>
                <option value="light">Leve (caminhadas)</option>
                <option value="moderate">Moderado (3x/semana)</option>
                <option value="active">Ativo (4-6x/semana)</option>
                <option value="very_active">Muito Ativo (atleta)</option>
            </Select>
            <Select label="Pratica esportes?" name="practicesSports" value={String(profile.practicesSports)} onChange={handleChange}>
                <option value="true">Sim</option>
                <option value="false">Não</option>
            </Select>
            {profile.practicesSports && (
                <Select label="Qual esporte?" name="sport" value={profile.sport} onChange={handleChange}>
                    <option value="">Selecione...</option>
                    <option value="walking">Caminhada</option>
                    <option value="running">Corrida</option>
                    <option value="gym">Academia</option>
                    <option value="yoga">Yoga</option>
                    <option value="functional">Funcional</option>
                    <option value="team_sports">Esportes Coletivos</option>
                    <option value="other">Outro</option>
                </Select>
            )}
            {profile.practicesSports && profile.sport === 'other' && (
                <Input label="Qual?" name="otherSport" value={profile.otherSport || ''} onChange={handleChange} />
            )}
        </FormSection>

        <FormSection title="3. Objetivos do Usuário">
            <Select label="Objetivo principal" name="goal" value={profile.goal} onChange={handleChange}>
                <option value="lose_weight">Perder peso</option>
                <option value="gain_muscle">Ganhar massa muscular</option>
                <option value="tone_body">Definir o corpo</option>
                <option value="improve_fitness">Melhorar condicionamento</option>
                <option value="maintain_weight">Manter o peso atual</option>
                <option value="reduce_measurements">Reduzir medidas</option>
                <option value="healthier_lifestyle">Vida mais saudável</option>
            </Select>
            <Input label="Peso Desejado (kg)" name="targetWeight" type="number" value={profile.targetWeight || ''} onChange={handleChange} />
        </FormSection>
        
        <FormSection title="4. Estado de Saúde">
            <div className="space-y-2">
              <p className="font-medium">Condições de atenção (opcional)</p>
              <Checkbox label="Hipertensão" name="healthConditions" value="hypertension" checked={profile.healthConditions.includes('hypertension')} onChange={handleMultiSelectChange} />
              <Checkbox label="Diabetes" name="healthConditions" value="diabetes" checked={profile.healthConditions.includes('diabetes')} onChange={handleMultiSelectChange} />
              <Checkbox label="Problemas nas articulações" name="healthConditions" value="joint_problems" checked={profile.healthConditions.includes('joint_problems')} onChange={handleMultiSelectChange} />
              <Checkbox label="Problemas no coração" name="healthConditions" value="heart_problems" checked={profile.healthConditions.includes('heart_problems')} onChange={handleMultiSelectChange} />
              <Checkbox label="Nenhuma das opções" name="healthConditions" value="none" checked={profile.healthConditions.includes('none')} onChange={handleMultiSelectChange} />
            </div>
             <div className="space-y-2">
              <p className="font-medium">Alergias ou restrições alimentares</p>
                <Checkbox label="Lactose" name="allergies" value="lactose" checked={profile.allergies.includes('lactose')} onChange={handleMultiSelectChange} />
                <Checkbox label="Glúten" name="allergies" value="gluten" checked={profile.allergies.includes('gluten')} onChange={handleMultiSelectChange} />
                <Checkbox label="Amendoim / castanhas" name="allergies" value="peanuts" checked={profile.allergies.includes('peanuts')} onChange={handleMultiSelectChange} />
                <Checkbox label="Ovos" name="allergies" value="eggs" checked={profile.allergies.includes('eggs')} onChange={handleMultiSelectChange} />
                <Checkbox label="Frutos do mar" name="allergies" value="seafood" checked={profile.allergies.includes('seafood')} onChange={handleMultiSelectChange} />
                <Checkbox label="Nenhuma" name="allergies" value="none" checked={profile.allergies.includes('none')} onChange={handleMultiSelectChange} />
            </div>
        </FormSection>

        <Button type="submit" className="w-full">Salvar Alterações</Button>
      </form>
    </Modal>
  );
};

export default ProfileModal;