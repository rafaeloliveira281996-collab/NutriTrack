
import React from 'react';
import { useApp } from '../contexts/AppContext';
import { Modal } from '../components/ui/Modal';
import { BellIcon } from '../components/icons/BellIcon';

const NotificationsModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { notifications, markNotificationAsRead } = useApp();

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Notificações">
      <div className="space-y-3">
        {notifications.length > 0 ? (
          notifications.map(n => (
            <div
              key={n.id}
              onClick={() => markNotificationAsRead(n.id)}
              className={`p-3 rounded-lg flex items-start gap-3 cursor-pointer ${
                n.read ? 'opacity-60' : 'bg-light-background dark:bg-dark-background'
              }`}
            >
              <div className={`mt-1 p-1.5 rounded-full ${ n.type === 'success' ? 'bg-accent/20 text-accent' : 'bg-blue-500/20 text-blue-500' }`}>
                <BellIcon className="h-5 w-5"/>
              </div>
              <div>
                <p className="text-sm">{n.message}</p>
                <p className="text-xs text-light-subtext dark:text-dark-subtext">{new Date(n.timestamp).toLocaleString()}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-light-subtext dark:text-dark-subtext py-8">Nenhuma notificação</p>
        )}
      </div>
    </Modal>
  );
};

export default NotificationsModal;
