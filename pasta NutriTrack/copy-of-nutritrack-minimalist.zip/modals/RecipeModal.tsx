
import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Modal } from '../components/ui/Modal';
import { Button } from '../components/ui/Button';
import { Recipe, MealType } from '../types';

interface RecipeModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipe: Recipe;
}

const RecipeModal: React.FC<RecipeModalProps> = ({ isOpen, onClose, recipe }) => {
    const { addFood } = useApp();
    const [selectedMeal, setSelectedMeal] = useState<MealType>('lunch');

    const handleAddToDiary = () => {
        recipe.ingredients.forEach(ing => {
            addFood(selectedMeal, ing.item);
        });
        onClose();
    };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={recipe.name}>
      <div className="space-y-4">
        <img src={`https://picsum.photos/seed/${recipe.id}/400/200`} alt={recipe.name} className="rounded-lg w-full h-40 object-cover" />
        
        <div>
            <h4 className="font-bold mb-2">Ingredientes</h4>
            <ul className="list-disc list-inside text-sm space-y-1 bg-light-background dark:bg-dark-background p-3 rounded-lg">
                {recipe.ingredients.map((ing, i) => (
                    <li key={i}>{ing.amount} {ing.name}</li>
                ))}
            </ul>
        </div>
        <div>
            <h4 className="font-bold mb-2">Modo de Preparo</h4>
            <ol className="list-decimal list-inside text-sm space-y-1">
                {recipe.instructions.map((step, i) => (
                    <li key={i}>{step}</li>
                ))}
            </ol>
        </div>

        <div className="border-t border-light-border dark:border-dark-border pt-4 space-y-2">
            <div className="flex items-center space-x-2">
                <label className="text-sm font-medium">Adicionar em:</label>
                <select value={selectedMeal} onChange={e => setSelectedMeal(e.target.value as MealType)} className="bg-light-background dark:bg-dark-background border border-light-border dark:border-dark-border rounded-lg px-2 py-1 text-sm">
                    <option value="breakfast">Café da manhã</option>
                    <option value="lunch">Almoço</option>
                    <option value="dinner">Jantar</option>
                    <option value="snack">Lanche</option>
                </select>
            </div>
            <Button onClick={handleAddToDiary} className="w-full">Adicionar ao Diário</Button>
        </div>
      </div>
    </Modal>
  );
};

export default RecipeModal;
