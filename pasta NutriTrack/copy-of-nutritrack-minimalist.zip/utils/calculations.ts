import { Profile, NutritionalGoals, UserGoal } from '../types';

const activityLevelMultipliers = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
  very_active: 1.9,
};

const mapGoalToSimpleGoal = (goal: UserGoal): 'lose' | 'maintain' | 'gain' => {
  switch (goal) {
    case 'lose_weight':
    case 'reduce_measurements':
      return 'lose';
    case 'gain_muscle':
      return 'gain';
    case 'tone_body':
    case 'improve_fitness':
    case 'maintain_weight':
    case 'healthier_lifestyle':
    default:
      return 'maintain';
  }
};


export const calculateNutritionalNeeds = (profile: Profile): NutritionalGoals => {
  const { weight, height, age, sex, activityLevel, goal } = profile;

  // Harris-Benedict Equation for BMR
  let bmr: number;
  if (sex === 'male') {
    bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
  } else { // 'female' or 'prefer_not_to_say' defaults to female calculation
    bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
  }

  const tdee = bmr * activityLevelMultipliers[activityLevel];
  
  const simpleGoal = mapGoalToSimpleGoal(goal);

  let targetCalories: number;
  switch (simpleGoal) {
    case 'lose':
      targetCalories = tdee - 500;
      break;
    case 'gain':
      targetCalories = tdee + 500;
      break;
    case 'maintain':
    default:
      targetCalories = tdee;
      break;
  }

  // Macronutrient distribution (example: 40% carbs, 30% protein, 30% fat)
  const proteinGrams = (targetCalories * 0.30) / 4;
  const carbsGrams = (targetCalories * 0.40) / 4;
  const fatGrams = (targetCalories * 0.30) / 9;

  // Water intake recommendation (e.g., 35ml per kg of body weight)
  const waterMl = weight * 35;

  return {
    calories: Math.round(targetCalories),
    protein: Math.round(proteinGrams),
    carbs: Math.round(carbsGrams),
    fat: Math.round(fatGrams),
    water: Math.round(waterMl),
  };
};